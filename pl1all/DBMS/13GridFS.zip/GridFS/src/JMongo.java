import java.io.File;
import java.io.IOException;
import java.net.UnknownHostException;

import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.Mongo;
import com.mongodb.MongoException;
import com.mongodb.gridfs.GridFS;
import com.mongodb.gridfs.GridFSDBFile;
import com.mongodb.gridfs.GridFSInputFile;


public class JMongo {
	
	public static void main(String[] args) throws UnknownHostException {
		  
		try{
		  Mongo mongo = new Mongo("localhost", 27017);
		  DB db = mongo.getDB("imagedb");
		  DBCollection coll = db.getCollection("picture");
		  
		  String newFileName = "jm_image";
		  
		  File imageFile = new File("/home/mrunmayi/Desktop/jfords.jpg");
		  
		  // create a "photo" namespace
		  GridFS gfsPhoto = new GridFS(db, "jmphoto");
		  
		  // get image file from local drive
		  GridFSInputFile gfsFile = gfsPhoto.createFile(imageFile);
		  
		  // set a new filename for identify purpose
		  gfsFile.setFilename(newFileName);
		  
		  // save the image file into mongoDB
		  gfsFile.save();
		  
		  // print the result
		  DBCursor cursor = gfsPhoto.getFileList();
		  while (cursor.hasNext()) 
		  {
			  System.out.println(cursor.next());
		  }
		  
		// get image file by it's filename
		GridFSDBFile imageForOutput = gfsPhoto.findOne(newFileName);
		
		// save it into a new image file
		imageForOutput.writeTo("/home/mrunmayi/Desktop/jm_output.jpg");
		
		// remove the image file from mongoDB
		gfsPhoto.remove(gfsPhoto.findOne(newFileName));
		System.out.println("Done");
		
		} //try ends
		
		catch (UnknownHostException e) 
		{	e.printStackTrace(); }
		
	    catch (MongoException e) 
	    {	e.printStackTrace(); }
		
		catch (IOException e) 
		{	e.printStackTrace(); }
		 		
		//all catch end
			 
	} //main ends

}	//class ends
